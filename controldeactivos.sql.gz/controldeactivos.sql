-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-10-2019 a las 23:07:04
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `controldeactivos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cronograma`
--

CREATE TABLE `cronograma` (
  `codigo_c` int(11) NOT NULL,
  `fecha_rev` varchar(50) DEFAULT NULL,
  `tipo_man` varchar(50) DEFAULT NULL,
  `fecha_inicio` varchar(50) DEFAULT NULL,
  `fecha_termino` varchar(50) DEFAULT NULL,
  `observacion` varchar(50) DEFAULT NULL,
  `fallas` varchar(50) DEFAULT NULL,
  `cod_tec` int(11) DEFAULT NULL,
  `cod_maq` int(11) DEFAULT NULL,
  `cod_man` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lista_activos`
--

CREATE TABLE `lista_activos` (
  `cod_maq` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `des_tecnica` varchar(50) DEFAULT NULL,
  `fecha_compra` varchar(50) DEFAULT NULL,
  `fecha_insta` varchar(50) DEFAULT NULL,
  `vida_horas` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `lista_activos`
--

INSERT INTO `lista_activos` (`cod_maq`, `nombre`, `des_tecnica`, `fecha_compra`, `fecha_insta`, `vida_horas`) VALUES
(1, 'pedro', 'es una maquina', '16/05/1999', '16/08/2000', '2'),
(2, 'asd', 'asdasd', '2019-09-13', '2019-09-02', '2'),
(3, 'producto3', 'es un producto', '2019-09-03', '2019-09-12', '21'),
(4, 'producto4', 'es un producto', '2019-09-05', '2019-09-09', '5'),
(5, 'producto5', 'este es un producto', '2019-09-19', '2019-09-18', '5'),
(6, 'producto6', 'este es un producto', '2019-09-14', '2019-09-20', '42'),
(7, 'producto 6', 'un producto', '2019-09-13', '2019-09-20', '32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tecnico`
--

CREATE TABLE `tecnico` (
  `cod_tec` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_mantenimiento`
--

CREATE TABLE `tipo_mantenimiento` (
  `cod_man` int(11) NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cronograma`
--
ALTER TABLE `cronograma`
  ADD PRIMARY KEY (`codigo_c`),
  ADD KEY `cod_tec` (`cod_tec`),
  ADD KEY `cod_man` (`cod_man`),
  ADD KEY `cod_maq` (`cod_maq`);

--
-- Indices de la tabla `lista_activos`
--
ALTER TABLE `lista_activos`
  ADD PRIMARY KEY (`cod_maq`);

--
-- Indices de la tabla `tecnico`
--
ALTER TABLE `tecnico`
  ADD PRIMARY KEY (`cod_tec`);

--
-- Indices de la tabla `tipo_mantenimiento`
--
ALTER TABLE `tipo_mantenimiento`
  ADD PRIMARY KEY (`cod_man`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cronograma`
--
ALTER TABLE `cronograma`
  MODIFY `codigo_c` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `lista_activos`
--
ALTER TABLE `lista_activos`
  MODIFY `cod_maq` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `tecnico`
--
ALTER TABLE `tecnico`
  MODIFY `cod_tec` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_mantenimiento`
--
ALTER TABLE `tipo_mantenimiento`
  MODIFY `cod_man` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cronograma`
--
ALTER TABLE `cronograma`
  ADD CONSTRAINT `cronograma_ibfk_1` FOREIGN KEY (`cod_tec`) REFERENCES `tecnico` (`cod_tec`),
  ADD CONSTRAINT `cronograma_ibfk_2` FOREIGN KEY (`cod_man`) REFERENCES `tipo_mantenimiento` (`cod_man`),
  ADD CONSTRAINT `cronograma_ibfk_3` FOREIGN KEY (`cod_maq`) REFERENCES `lista_activos` (`cod_maq`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
